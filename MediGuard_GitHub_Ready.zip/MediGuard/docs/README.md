# Project documentation

Add project-owned material here as it becomes available:

- A labelled architecture diagram.
- The final wiring diagram checked against the actual ESP32 board.
- Photos of the real prototype.
- Test procedure, ambient conditions, sensor reference, and measured results.

Keep simulated dashboard screenshots clearly labelled as simulated. Do not present simulated readings as evidence of hardware performance.
